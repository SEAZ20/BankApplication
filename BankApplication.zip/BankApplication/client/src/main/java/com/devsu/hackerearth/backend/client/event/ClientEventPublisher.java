package com.devsu.hackerearth.backend.client.event;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import com.devsu.hackerearth.backend.client.config.RabbitConfig;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RequiredArgsConstructor
public class ClientEventPublisher {

    private final RabbitTemplate rabbitTemplate;

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onClientEvent(ClientEvent event){
        try {
            rabbitTemplate.convertAndSend(RabbitConfig.EXCHANGE, RabbitConfig.ROUTING_KEY_UPSERTED, event);
            log.info("ClientEvent Publicado para clientId={}", event.getClientId());
        }catch (AmqpException ex){
            log.error("No se pudo publicar ClientEvent para clientId={}", event.getClientId());
        }
    }
}