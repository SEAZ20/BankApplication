package com.devsu.hackerearth.backend.client.model;

import javax.persistence.Entity;
import lombok.Getter;
import lombok.Setter;
import javax.persistence.Table;
import javax.persistence.Column;

@Getter @Setter
@Entity
@Table(name = "client")
public class Client extends Person {
	@Column(nullable = false)
	private String password;
	@Column(nullable = false)
	private boolean isActive;
}
