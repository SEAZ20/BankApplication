package com.devsu.hackerearth.backend.client.model.dto;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties({"active"})
public class ClientDto {

	@JsonProperty(access = JsonProperty.Access.READ_ONLY)
	private Long id;

	@NotBlank(message = "El dni es oblogatorio")
	private String dni;
	@NotBlank(message = "El dni es oblogatorio")
	private String name;
	@NotBlank(message = "El dni es oblogatorio")
	@JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
	private String password;
	private String gender;

	@Min(value = 0, message = "La edad no puede ser negativa")
	private int age;
	private String address;
	private String phone;
	@JsonProperty("isActive")
	private boolean isActive = true;
}
