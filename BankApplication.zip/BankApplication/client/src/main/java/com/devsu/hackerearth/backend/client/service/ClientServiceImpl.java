package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;
import com.devsu.hackerearth.backend.client.event.ClientEvent;
import com.devsu.hackerearth.backend.client.exception.DuplicateResourceException;
import com.devsu.hackerearth.backend.client.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.client.mapper.ClientMapper;
import com.devsu.hackerearth.backend.client.model.Client;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.transaction.annotation.Transactional;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;
	private final ApplicationEventPublisher eventPublisher;

	@Override
	@Transactional(readOnly = true)
	public List<ClientDto> getAll() {
	   return clientRepository.findAll().stream()
	          .map(ClientMapper::toDto)
			  .collect(Collectors.toList());
	}

	@Override
	@Transactional(readOnly = true)
	public ClientDto getById(Long id) {
		return clientRepository.findById(id).map(ClientMapper::toDto)
		.orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id " + id));
	}

	@Override
	@Transactional
	public ClientDto create(ClientDto clientDto) {
		if(clientRepository.existsByDni(clientDto.getDni())){
			throw new DuplicateResourceException("Ya existe un cliente con DNI" + clientDto.getDni());
		}
        
		Client saved = clientRepository.save(ClientMapper.toEntity(clientDto));

		eventPublisher.publishEvent(new ClientEvent(saved.getId(), saved.getName(), saved.isActive()));
		
		return ClientMapper.toDto(saved);
	}

	@Override
	@Transactional
	public ClientDto update(ClientDto clientDto) {
		Long id = clientDto.getId();
		Client client = clientRepository.findById(id)
		.orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id " + id));
      
		if(clientRepository.existsByDniAndIdNot(clientDto.getDni(), id)){
			throw new DuplicateResourceException("Ya existe otro cliente con DNI " + clientDto.getDni());
		}

		ClientMapper.updateEntity(client, clientDto);
		Client saved = clientRepository.save(client);

		eventPublisher.publishEvent(new ClientEvent(saved.getId(), saved.getName(), saved.isActive()));
		return ClientMapper.toDto(saved);
	}

	@Override
	@Transactional
    public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
        Client client = clientRepository.findById(id)
		.orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id " + id));

		client.setActive(partialClientDto.isActive());
		Client saved = clientRepository.save(client);

		eventPublisher.publishEvent(new ClientEvent(saved.getId(), saved.getName(), saved.isActive()));
		return ClientMapper.toDto(saved);
    }

	@Override
	@Transactional
	public void deleteById(Long id) {
		Client client = clientRepository.findById(id)
		.orElseThrow(() -> new ResourceNotFoundException("Cliente no encontrado con id " + id));

		clientRepository.delete(client);

		eventPublisher.publishEvent(new ClientEvent(client.getId(), client.getName(), false));
	}
}
