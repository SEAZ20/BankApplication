package com.devsu.hackerearth.backend.client.mapper;

import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.Client;
public final class ClientMapper {


    private ClientMapper(){

    }

    public static Client toEntity(ClientDto dto){
        Client client = new Client();
        client.setDni(dto.getDni());
        client.setName(dto.getName());
        client.setGender(dto.getGender());
        client.setPassword(dto.getPassword());
        client.setAge(dto.getAge());
        client.setAddress(dto.getAddress());
        client.setPhone(dto.getPhone());
        client.setActive(dto.isActive());
        return client;
    } 

    public static ClientDto toDto(Client client){
        ClientDto dto = new ClientDto();
        dto.setId(client.getId());
        dto.setDni(client.getDni());
        dto.setName(client.getName());
        dto.setGender(client.getGender());
        dto.setPassword(client.getPassword());
        dto.setAge(client.getAge());
        dto.setAddress(client.getAddress());
        dto.setPhone(client.getPhone());
        dto.setActive(client.isActive());
        return dto;
    } 

    
    public static void updateEntity(Client client, ClientDto dto){
        client.setDni(dto.getDni());
        client.setName(dto.getName());
        client.setGender(dto.getGender());
        client.setAge(dto.getAge());
        client.setAddress(dto.getAddress());
        client.setPhone(dto.getPhone());
        client.setActive(dto.isActive());
        if(dto.getPassword() != null && !dto.getPassword().isBlank()){
            client.setPassword(dto.getPassword());
        }
    } 

} 
