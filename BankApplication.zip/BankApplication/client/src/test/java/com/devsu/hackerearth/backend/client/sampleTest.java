package com.devsu.hackerearth.backend.client;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.mockito.Mockito.*;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import com.devsu.hackerearth.backend.client.config.RabbitConfig;
import com.devsu.hackerearth.backend.client.controller.ClientController;
import com.devsu.hackerearth.backend.client.event.ClientEvent;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.service.ClientService;
import com.fasterxml.jackson.databind.ObjectMapper;

@SpringBootTest
@AutoConfigureMockMvc
public class sampleTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private RabbitTemplate rabbitTemplate;


    @Test
    void clientEntityTest(){
        Client client = new Client();

        client.setName("Silvio Alcivar");
        client.setDni("1234567890");
        client.setGender("Masculino");
        client.setAge(28);
        client.setAddress("Calceta calle chile");
        client.setPhone("098254785");
        client.setPassword("1234");
        client.setActive(true);

        assertEquals("Silvio Alcivar", client.getName());
        assertEquals("1234567890", client.getDni());
        assertEquals("Masculino", client.getGender());
        assertEquals(28, client.getAge());
        assertEquals("Calceta calle chile", client.getAddress());
        assertEquals("098254785", client.getPhone());
        assertEquals("1234", client.getPassword());
        assertTrue(client.isActive());
    }

 
    @Test
    void createAndGetClientIntegractionTest() throws Exception {
        Map<String, Object> request = new HashMap<>();
        request.put("dni", "0912345678");
        request.put("name", "Enrique Alcivar");
        request.put("password", "5678");
        request.put("gender", "Femenino");
        request.put("age", 28);
        request.put("address", "Antonio granda centeno");
        request.put("phone", "097548965");
        request.put("isActive", true);


        MvcResult result = mockMvc.perform(post("/api/clients")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").exists())
                .andExpect(jsonPath("$.name").value("Enrique Alcivar"))
                .andExpect(jsonPath("$.isActive").value(true))
                .andExpect(jsonPath("$.password").doesNotExist())
                .andReturn();

        long id = objectMapper.readTree(result.getResponse().getContentAsString()).get("id").asLong();

        mockMvc.perform(get("/api/clients/{id}",id))
               .andExpect(status().isOk())
               .andExpect(jsonPath("$.dni").value("0912345678"))
               .andExpect(jsonPath("$.name").value("Enrique Alcivar"));

        verify(rabbitTemplate).convertAndSend(
            eq(RabbitConfig.EXCHANGE),
            eq(RabbitConfig.ROUTING_KEY_UPSERTED),
            any(ClientEvent.class)
        );
    }
}
