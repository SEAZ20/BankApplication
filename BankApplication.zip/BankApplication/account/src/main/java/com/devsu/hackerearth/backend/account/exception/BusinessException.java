package com.devsu.hackerearth.backend.account.exception;

public class BusinessException extends RuntimeException{

    public BusinessException(String message){
        super(message);
    }
}