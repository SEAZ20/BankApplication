package com.devsu.hackerearth.backend.account.config;

import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.amqp.support.converter.DefaultJackson2JavaTypeMapper;
import org.springframework.amqp.support.converter.Jackson2JavaTypeMapper;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig{

    public static final String EXCHANGE = "client.exchange";
    public static final String QUEUE = "account.client.queue";
    public static final String ROUTING_PATTERN = "client.*";

    public static final String DEAD_LETTER_EXCHANGE = "client.dlx";
    public static final String DEAD_LETTER_QUEUE = "account.client.queue.dlq";
    public static final String DEAD_LETTER_ROUTING_KEY = "account.client.dlq";
 
    @Bean
    public TopicExchange clientExchange(){
        return new TopicExchange(EXCHANGE, true, false);
    }

    @Bean
    public Queue accountClientQueue(){
        return QueueBuilder.durable(QUEUE)
            .deadLetterExchange(DEAD_LETTER_EXCHANGE)
            .deadLetterRoutingKey(DEAD_LETTER_ROUTING_KEY)
            .build();
    }

    @Bean
    public Binding accountClientBinding(){
        return BindingBuilder.bind(accountClientQueue()).to(clientExchange()).with(ROUTING_PATTERN);
    }

    @Bean
    public DirectExchange deadLetterExchange(){
        return new DirectExchange(DEAD_LETTER_EXCHANGE,true,false);
    }

    @Bean
    public Queue deadLetterQueue(){
        return QueueBuilder.durable(DEAD_LETTER_QUEUE).build();
    }

    @Bean
    public Binding deadLetterQueueBinding(){
        return BindingBuilder.bind(deadLetterExchange()).to(deadLetterExchange()).with(DEAD_LETTER_ROUTING_KEY);
    }

    @Bean
    public MessageConverter jsonMessageConverter(){

        DefaultJackson2JavaTypeMapper typeMapper = new DefaultJackson2JavaTypeMapper();

        typeMapper.setTypePrecedence(Jackson2JavaTypeMapper.TypePrecedence.INFERRED);
        typeMapper.setTrustedPackages("*");

        Jackson2JsonMessageConverter converter = new Jackson2JsonMessageConverter();
        converter.setJavaTypeMapper(typeMapper);

        return converter;
    }

}