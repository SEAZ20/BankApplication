package com.devsu.hackerearth.backend.account.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Getter;
import lombok.Setter;
import javax.persistence.Table;

import javax.persistence.Column;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "client_snapshot")
public class ClientSnapshot {

	@Id
	@Column(name = "client_id")
	private Long clientId;
	@Column(nullable = false)
	private String name;
	@Column(nullable = false)
	private boolean status;
}
