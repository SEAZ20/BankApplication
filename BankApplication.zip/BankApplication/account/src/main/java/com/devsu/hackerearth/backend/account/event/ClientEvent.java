package com.devsu.hackerearth.backend.account.event;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientEvent {

	private Long clientId;
	private String name;
	private boolean status;
}