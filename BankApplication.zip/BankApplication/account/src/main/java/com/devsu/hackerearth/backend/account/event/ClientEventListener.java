package com.devsu.hackerearth.backend.account.event;

import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.repository.ClientSnapshotRepository;
import com.devsu.hackerearth.backend.account.config.RabbitConfig;
import com.devsu.hackerearth.backend.account.model.ClientSnapshot;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@RequiredArgsConstructor
public class ClientEventListener {

    private final ClientSnapshotRepository clientSnapshotRepository;


    @Transactional
    @RabbitListener(queues = RabbitConfig.QUEUE)
    public void onClientEvent(ClientEvent event){
        if(event == null || event.getClientId() == null || event.getName() == null){
            throw new AmqpRejectAndDontRequeueException("ClientEven invalido "+ event);
        }

        ClientSnapshot clientSnapshot = clientSnapshotRepository.findById(event.getClientId())
                .orElseGet(ClientSnapshot::new);
        
        clientSnapshot.setClientId(event.getClientId());
        clientSnapshot.setName(event.getName());
        clientSnapshot.setStatus(event.isStatus());

        clientSnapshotRepository.save(clientSnapshot);
        log.info("client_snapshot actualizado para clientId={}", event.getClientId());
    }
}