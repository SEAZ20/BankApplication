package com.devsu.hackerearth.backend.account.mapper;

import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.model.Transaction;

public final class TransactionMapper {


    private TransactionMapper(){

    }

    public static TransactionDto toDto(Transaction transaction){
        TransactionDto dto =  new TransactionDto();

        dto.setId(transaction.getId());
        dto.setType(transaction.getType());
        dto.setAccountId(transaction.getAccountId());
        dto.setAmount(transaction.getAmount());
        dto.setDate(transaction.getDate());
        dto.setBalance(transaction.getBalance());
        return dto;
    }
}
