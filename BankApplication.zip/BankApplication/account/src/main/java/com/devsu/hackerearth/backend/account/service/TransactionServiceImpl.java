package com.devsu.hackerearth.backend.account.service;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.mapper.TransactionMapper;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.ClientSnapshot;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.ClientSnapshotRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;
import com.devsu.hackerearth.backend.account.exception.BusinessException;
import com.devsu.hackerearth.backend.account.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.account.exception.InsufficientBalanceException;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TransactionServiceImpl implements TransactionService {

    private static final long ONE_DAY_MS = 24L * 60 * 60 * 1000;

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;
    private final ClientSnapshotRepository clientSnapshotRepository;

    @Override
    @Transactional(readOnly = true)
    public List<TransactionDto> getAll() {
        return transactionRepository.findAll().stream()
                .map(TransactionMapper::toDto)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public TransactionDto getById(Long id) {
        return transactionRepository.findById(id).map(TransactionMapper::toDto)
                .orElseThrow(() -> new ResourceNotFoundException("Transaccion no encontrada con id " + id));
    }

    @Override
    @Transactional
    public TransactionDto create(TransactionDto transactionDto) {
        if (transactionDto.getAmount() == 0) {
            throw new BusinessException("El monto del movmiento no puede ser 0");
        }

        Account account = accountRepository.findByIdForUpdate(transactionDto.getAccountId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Cuenta no encontrsada con id " + transactionDto.getAccountId()));

        if (!account.isActive()) {
            throw new BusinessException("La cuenta " + account.getNumber() + "esta inactiva");
        }

        double currentBalance = transactionRepository.findTopByAccountIdOrderByIdDesc(account.getId())
                .map(Transaction::getBalance)
                .orElse(account.getInitialAmount());

        double newBalance = currentBalance + transactionDto.getAmount();
        if (newBalance < 0) {
            throw new InsufficientBalanceException();
        }

        Transaction transaction = new Transaction();
        transaction.setDate(transactionDto.getDate() != null ? transactionDto.getDate() : new Date());
        transaction.setType(resolveType(transactionDto));
        transaction.setAmount(transactionDto.getAmount());
        transaction.setBalance(newBalance);
        transaction.setAccountId(account.getId());

        return TransactionMapper.toDto(transactionRepository.save(transaction));
    }

    @Override
    @Transactional(readOnly = true)
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        if (dateTransactionStart.after(dateTransactionEnd)) {
            throw new BusinessException("La fecha de inicio no puede ser mayo a la fecha fin");
        }

        String clientName = clientSnapshotRepository.findById(clientId)
               .map(ClientSnapshot::getName)
               .orElseThrow(() -> new ResourceNotFoundException("Cliente no encontradao con id " + clientId));

        Map<Long, Account> accounts = accountRepository.findByClientId(clientId).stream()
                .collect(Collectors.toMap(Account::getId, Function.identity()));
        
        if(accounts.isEmpty()){
            return List.of();
        }

        Date endOfDay = new Date(dateTransactionEnd.getTime() + ONE_DAY_MS - 1);


        return transactionRepository.findByAccountIdInAndDateBetweenOrderByDateAsc(accounts.keySet(), dateTransactionStart, endOfDay)
               .stream()
               .map(tx -> {
                    Account account = accounts.get(tx.getAccountId());
                    return new BankStatementDto(
                        tx.getDate(),
                        clientName,
                        account.getNumber(),
                        account.getType(),
                        account.getInitialAmount(),
                        account.isActive(),
                        tx.getType(),
                        tx.getAmount(),
                        tx.getBalance()
                    );
               })
               .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public TransactionDto getLastByAccountId(Long accountId) {
        
        return transactionRepository.findTopByAccountIdOrderByIdDesc(accountId)
               .map(TransactionMapper::toDto)
               .orElseThrow(() -> new ResourceNotFoundException("La cuenta " + accountId + "no tiene movimientos"));
    }

    private String resolveType(TransactionDto dto){
        if(dto.getType() != null && !dto.getType().isBlank()){
            return dto.getType();
        }

       return dto.getAmount() > 0 ? "Deposito" : "Retiro";
    }

}
