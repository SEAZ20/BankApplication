package com.devsu.hackerearth.backend.account.mapper;

import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.Account;
public final class AccountMapper {


    private AccountMapper(){

    }

    public static Account toEntity(AccountDto dto){
        Account account = new Account();
        updateEntity(account, dto);
        return account;
    } 

      
    public static void updateEntity(Account account, AccountDto dto){
        account.setNumber(dto.getNumber());
        account.setType(dto.getType());
        account.setInitialAmount(dto.getInitialAmount());
        account.setActive(dto.isActive());
        account.setClientId(dto.getClientId());
    } 

    public static AccountDto toDto(Account account){
        AccountDto dto = new AccountDto();
        dto.setId(account.getId());
        dto.setNumber(account.getNumber());
        dto.setInitialAmount(account.getInitialAmount());
        dto.setType(account.getType());
        dto.setActive(account.isActive());
        dto.setClientId(account.getClientId());
        return dto;
    } 

  

} 
