package com.devsu.hackerearth.backend.account.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.devsu.hackerearth.backend.account.exception.BusinessException;
import com.devsu.hackerearth.backend.account.exception.ResourceNotFoundException;
import com.devsu.hackerearth.backend.account.mapper.AccountMapper;
import com.devsu.hackerearth.backend.account.model.dto.AccountDto;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.ClientSnapshot;
import com.devsu.hackerearth.backend.account.model.dto.PartialAccountDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.ClientSnapshotRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {

	private final AccountRepository accountRepository;
    private final ClientSnapshotRepository clientSnapshotRepository;

    @Override
    @Transactional(readOnly = true)
    public List<AccountDto> getAll() {
        return accountRepository.findAll().stream()
        .map(AccountMapper::toDto)
        .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public AccountDto getById(Long id) {
       return AccountMapper.toDto(findAccount(id));
    }

    @Override
    @Transactional
    public AccountDto create(AccountDto accountDto) {
        validateActiveClient(accountDto.getClientId());

        if(accountRepository.existsByNumber(accountDto.getNumber())){
            throw new  BusinessException("Ya existe una cuenta con el numero "+ accountDto.getNumber());
        }

        Account saved = accountRepository.save(AccountMapper.toEntity(accountDto));
		return AccountMapper.toDto(saved);
    }

    @Override
    @Transactional
    public AccountDto update(AccountDto accountDto) {
        Long id = accountDto.getId();
        Account account = findAccount(id);
        validateActiveClient(accountDto.getClientId());

        if(accountRepository.existsByNumber(accountDto.getNumber())){
            throw new  BusinessException("Ya existe otra cuenta con el numero "+ accountDto.getNumber());
        }
         
    
		 AccountMapper.updateEntity(account,accountDto);
         return AccountMapper.toDto(accountRepository.save(account));
    }

    @Override
    @Transactional
    public AccountDto partialUpdate(Long id, PartialAccountDto partialAccountDto) {
        Account account = findAccount(id);
        account.setActive(partialAccountDto.isActive());
		return AccountMapper.toDto(accountRepository.save(account));
    }

    @Override
    @Transactional
    public void deleteById(Long id) {
        accountRepository.delete(findAccount(id));
    }
    

    private Account findAccount(Long id){
        return accountRepository.findById(id)
        .orElseThrow(() -> new ResourceNotFoundException("Cuenta no econtrada con el id "+ id));
    }

    private void validateActiveClient(Long clientId){
        ClientSnapshot clientSnapshot = clientSnapshotRepository.findById(clientId)
        .orElseThrow(() -> new BusinessException("El cliente "+ clientId + " no existe"));

        if(!clientSnapshot.isStatus()){
            throw new BusinessException("El cliente "+ clientId + "esta inactivo");
        }
    }

}
