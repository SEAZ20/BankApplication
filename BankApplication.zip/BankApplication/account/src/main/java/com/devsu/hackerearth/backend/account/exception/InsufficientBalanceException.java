package com.devsu.hackerearth.backend.account.exception;

public class InsufficientBalanceException extends RuntimeException {

    public InsufficientBalanceException(){
        super("Saldo no disponible");
    }
}